UPLOAD_FOLDER = "uploads"

ASSEMBLY_API_KEY = "127abe5b669d4ff5853f33eaf05a2caf"
ASSEMBLY_BASE_URL = "https://api.assemblyai.com"
OPENROUTER_API_KEY = "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"
TTS_FOLDER = "tts_output"
HEADERS = {
    "authorization": ASSEMBLY_API_KEY,
    "content-type": "application/json"
}
